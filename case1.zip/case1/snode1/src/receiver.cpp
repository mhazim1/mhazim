#include "ros/ros.h"
#include "std_msgs/String.h"
#include <std_msgs/Empty.h>

#include <sstream>
 
 
 unsigned int prob,prob1,prob2;
 float delay1,delay2,randomn;
 bool startProcess;
 unsigned long int delay_ms;
 							
 void ImageReceivedCallback(const std_msgs::Empty& msg)
{
	/////the next steps is to generate the three probabilities of the first image////
	// Generate random in the range 1 to 100 (selecting probability of image 1)
	prob = rand() % 100 + 1;     
	if (prob<=30) {
		// Random delay between 3 .. 4
		prob1 = 1;
		//to generate random between 1..2
		randomn = ((float) rand()) / (float) RAND_MAX;
		delay1 = randomn + 3.0; 
	} else
	if ((prob>30)&&(prob<=90)) {
		// Random delay between 4 .. 6
		prob1 = 2;
		randomn = ((float) rand()) / (float) RAND_MAX;
		delay1 = randomn*2.0 + 4.0; 
	} else	{
		// Random delay between 6 .. 8
		prob1 = 3;
		randomn = ((float) rand()) / (float) RAND_MAX;
		delay1 = randomn*2.0 + 6.0; 
	};
	
	/////the next steps is to generate the three probabilities of the second image////
	// Generate random in the range 1 to 100 (selecting probability of image 2)
	prob = rand() % 100 + 1;     
	if (prob<=30) {
		// Random delay between 3 .. 4
		prob2 = 1;
		randomn = ((float) rand()) / (float) RAND_MAX;
		delay2 = randomn + 3.0; 
	} else
	if ((prob>30)&&(prob<=90)) {
		// Random delay between 4 .. 6
		prob2 = 2;
		randomn = ((float) rand()) / (float) RAND_MAX;
		delay2 = randomn*2.0 + 4.0; 
	} else	{
		// Random delay between 6 .. 8
		prob2 = 3;
		randomn = ((float) rand()) / (float) RAND_MAX;
		delay2 = randomn*2.0 + 6.0; 
	};
	
	////the next steps is to print the probabilites of the two images with there delays////
	printf("Image 1> prob %d  delay %.3f \n",prob1,delay1);
	printf("Image 2> prob %d  delay %.3f \n",prob2,delay2);
	
	////this is to find the time taken for the two images to be recieved by the first node in milisecond////
	delay_ms = (delay1 + delay2) * 1000000;
	
	startProcess = true;	
}
 
 
int main(int argc, char **argv)
{
	
	startProcess = false;
	
	ros::init(argc, argv, "ReceivingNode");
  
	ros::NodeHandle n;

	// Publish the "image" stream (simulated using text)
	ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);

	// Publish the timestamp (simulated using text)
	ros::Publisher receiverstatistic_pub = n.advertise<std_msgs::String>("receiverstatistic", 1000);
	

	// Subscribe to topic for starting the process
	ros::Subscriber sub = n.subscribe("ImageReceived", 1000, ImageReceivedCallback);
	ros::Rate loop_rate(10);


	int count = 0;
	while (ros::ok()){
		std_msgs::String msg,msgSnode;

		std::stringstream ss;
		//ss << "Transfering image " << count;

		// ROS_INFO("[talker] i published %s\n", msg.data.c_str());

		if (startProcess){
			++count;
			ss << count;
			msg.data = ss.str();

			
			printf("Start sending image %d\n",count);
			ros::Time begin = ros::Time::now();
			printf("%d,%d\n",begin.sec, begin.nsec);
			
			// send timestamp to S node
			std::stringstream ss2;
			// Node   1   is   Publishing   theTime    in Seconds and Nanoseconds.
			ss2 << "1;pub;" << count << ";" << begin.sec << ";" << begin.nsec << ";" ;
			msgSnode.data = ss2.str();
			receiverstatistic_pub.publish(msgSnode);
			
			//to simulate the case where the images need some time(according to the probability) to be transfered from receiving node to processing node
			usleep(delay_ms);
			chatter_pub.publish(msg);
			startProcess = false;
			printf("Image transfered \n");
			
		}
		ros::spinOnce();
		loop_rate.sleep();
	}


  return 0;
}
// %EndTag(FULLTEXT)%

