#include "ros/ros.h"
#include "std_msgs/String.h"
#include <std_msgs/Empty.h>

#include <sstream>
 
 
 unsigned int prob,prob1,prob2;
 float delay1,delay2,randomn;
 bool startProcess;
 unsigned long int delay_ms;
 int count = 0;
 std_msgs::String msgSnode;
 std_msgs::Empty msg;
 							
 void ImageReceivedCallback(const std_msgs::String::ConstPtr& msg)
{
	// Image received, send timestamp
	count = atoi( msg->data.c_str() );
	printf("Image received no %d \n",count);
	
	
	
	// Random success / fail selection
	prob = rand() % 100 + 1;     
	if (prob<=91) {
		prob1 = 1;
	} else {
		prob1 = 0;
	} 
	
	
	randomn = ((float) rand()) / (float) RAND_MAX;
	delay1 = randomn*4.0 + 12.0; 

	
	printf("Prob %d DELAY %.3f \n",prob1,delay1);
	delay_ms = (delay1) * 1000000;
	
	startProcess = true;	
}
 
 
int main(int argc, char **argv)
{
	
	startProcess = false;
	count = 0;
	
	ros::init(argc, argv, "ProcessorNode");
  
	ros::NodeHandle n;

	// Subscribe to the "image" stream (simulated using text)
    ros::Subscriber sub = n.subscribe("chatter", 1000, ImageReceivedCallback);	
	

	// Publish timestamp
	ros::Publisher processorstatistic_pub = n.advertise<std_msgs::String>("processorstatistic", 1000);
	
	// Publish to receiver node to ask re-sending image
	ros::Publisher asksendingimage_pub = n.advertise<std_msgs::Empty>("ImageReceived", 1000);

	ros::Rate loop_rate(10);
	



	while (ros::ok()){
		std::stringstream ss;


		if (startProcess){
			std::stringstream ss2;

			// send timestamp received image to s node
			ros::Time begin = ros::Time::now();			
			ss2.str("");
			ss2 << "2;rec;" << count << ";" << begin.sec << ";" << begin.nsec << ";" ;
			msgSnode.data = ss2.str();
			processorstatistic_pub.publish(msgSnode);
			
			printf("Start processing image %d\n",count);
			usleep(delay_ms);
			
			begin = ros::Time::now();
			printf("%d,%d\n",begin.sec, begin.nsec);

			
			// send timestamp end of processing to s node
			ss2.str("");
			ss2 << "2;proc;" << count << ";" << begin.sec << ";" << begin.nsec << ";" ;
			msgSnode.data = ss2.str();
			processorstatistic_pub.publish(msgSnode);
			
			if (prob1==1){
					printf("Successful recognition \n");	
			} else {
					printf("Fail recognition, ask receiver to send images \n");	
					asksendingimage_pub.publish(msg);
			}
			
			startProcess = false;
		
		}
		ros::spinOnce();
		loop_rate.sleep();
	}


  return 0;
}
// %EndTag(FULLTEXT)%

